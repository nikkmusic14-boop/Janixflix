Compress-Archive -Path * -DestinationPath ..\dist-correct.zip -Force  
